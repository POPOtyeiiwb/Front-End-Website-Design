<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>VGO Instructor</title>
   <link rel="icon" href="{!!asset('images/favicon-1.ico')!!}"/>
  <!-- Bootstrap core CSS-->
  <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet"> 
  <!-- Custom fonts for this template-->
  <link href="{{ asset('font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
  <!-- Page level plugin CSS-->
  <link href="{{ asset('datatables/dataTables.bootstrap4.css') }}" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="{{ asset('css/claim.css') }}" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="http://localhost/VGO/public/index">
      <div class="card" id="box">
         <img class = "logo" id="imag" src="{{URL::asset('/images/login_vgo_logo.png')}}" width="85" height="70" alt="vgologo">
       </div>
    </a>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Home">
          <a class="nav-link" href="http://localhost/VGO/public/index">
            <img class = "icon" src="{{URL::asset('/images/home_ic.svg')}}" width="20" height="20" align="center" >
            <span class="nav-link-text">Home</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Assigned Tasks">
          <a class="nav-link" href="http://localhost/VGO/public/assignedtask">
            <img class = "icon" src="{{URL::asset('/images/task_ic.svg')}}" width="20" height="20" align="center" >
            <span class="nav-link-text">Assigned Tasks</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Duty Roster">
          <a class="nav-link" href="http://localhost/VGO/public/duty">
            <img class = "icon" src="{{URL::asset('/images/duty_ic.svg')}}" width="20" height="20" align="center" >
            <span class="nav-link-text">Duty Roster</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Students">
          <a class="nav-link" href="http://localhost/VGO/public/student">
            <img class = "icon" src="{{URL::asset('/images/student_ic.svg')}}" width="20" height="20" align="center" >
            <span class="nav-link-text">Students</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Leave">
          <a class="nav-link" href="http://localhost/VGO/public/leave">
            <img class = "icon" src="{{URL::asset('/images/leave_ic.svg')}}" width="20" height="20" align="center" >
            <span class="nav-link-text">Leave</span>
          </a>
        </li>
        <li class="nav-item1" data-toggle="tooltip" data-placement="right" title="Claim">
          <a class="nav-link" href="http://localhost/VGO/public/claim">
            <img class = "icon" src="{{URL::asset('/images/claim_ic.svg')}}" width="20" height="20" align="center" >
            <span class="nav-link-text">Claim</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Notice">
          <a class="nav-link" href="http://localhost/VGO/public/notice">
            <img class = "icon" src="{{URL::asset('/images/notice_ic.svg')}}" width="20" height="20" align="center" >
            <span class="nav-link-text">Notice</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="VGO Calender">
          <a class="nav-link" href="http://localhost/VGO/public/calender">
            <img class = "icon" src="{{URL::asset('/images/calendar_ic.svg')}}" width="20" height="20" align="center" >
            <span class="nav-link-text">VGO Calender</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Payroll">
          <a class="nav-link" href="http://localhost/VGO/public/payroll">
            <img class = "icon" src="{{URL::asset('/images/payroll_ic.svg')}}" width="20" height="20" align="center" >
            <span class="nav-link-text">Payroll</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Feedback">
          <a class="nav-link" href="http://localhost/VGO/public/feedback">
            <img class = "icon" src="{{URL::asset('/images/feedback_ic.svg')}}" width="20" height="20" align="center" >
            <span class="nav-link-text">Feedback</span>
          </a>
        </li>
      </ul>


      <ul class="navbar-nav sidenav-toggler" >
      
      </ul> 
      <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown" id="clock">

           <a class="nav-link dropdown-toggle mr-lg-2" id="myBtn" href="#" aria-haspopup="true" aria-expanded="false">
              <img class="ww" src="{{URL::asset('/images/clock_ic.svg')}}" width="25" height="25" align="left" >
              <span class="aw">Clock In</span>
           </a>

            <!-- The Modal -->
            <div id="myModal" class="modal">

              <!-- Modal content -->
              <div class="modal-content">
                <span class="close">&times;</span>
                <p class="title">Clock In Now!</p>
                <form>
                <div class="form-group">
                  <label for="recipient-name" class="col-form-label">Time</label>
                  <input type="text" class="form-control" id="recipient-name">
                </div>
                <div class="form-group">
                  <label for="message-text" class="col-form-label">Date</label>
                  <input type="text" class="form-control" id="recipient-name">
                </div>
                <div class="form-group">
                  <label for="message-text" class="col-form-label">Branch</label>
                  <input type="text" class="form-control" id="recipient-name">
                </div>
              </form>
              <div class="modal-footer">
                <button type="button" class="clockin" data-dismiss="modal">Clock In</button>
              </div>
                
              </div>
            </div>
        </li>



        <li class="nav-item dropdown" id="notify">
          <a class="nav-link dropdown-toggle mr-lg-2" id="alertsDropdown" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img class = "pic2" src="{{URL::asset('/images/notification_ic.svg')}}" width="25" height="25" align="left" >
            <span class="aa">2</span>
          </a>
        </li>

        <li class="nav-item dropdown">
                 <a class="nav-link dropdown-toggle" id="profile" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                    <div class="banner">
                        <div class="nam1" >WONG SI HONG</div>
                        <div class="nam2">Swimming Instructor</div>
                    </div>
                    <div style="display:inline-block;">  
                       <img class="img-circle" src="{{URL::asset('/images/avatar-1.png')}}"  width="40" height="40" align="middle" > 
                    </div>
                  </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <div class="dropdown-header">Account</div>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-user"></i> Profile
                    </a>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-envelope"></i> Messages
                    </a>

                    <div class="dropdown-header">Settings</div>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-bell"></i> Notifications
                    </a>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-wrench"></i> Settings
                    </a>

                    <a href="#" class="dropdown-item" data-toggle="modal" data-target="#exampleModal">
                        <i class="fa fa-lock"></i> Logout
                    </a>
                </div>
            </li>
      </ul>
    </div>
  </nav>


   <div class="content-wrapper" style="overflow-y: scroll; height:200px;">
    <div class="container-fluid">
      <div class="content">
        <div class="row">
          <button id="butn"><span class="aww">Add New Claim</span></button>

                             <!-- The Modal -->
                                  <div id="Modal" class="modal1">

                                    <!-- Modal content -->
                                    <div class="modal-cont">
                                      <span class="close1">&times;</span>
                                      <p class="title">Add New Claim</p>
                                      <form>
                                      <div class="form-group" id="gx">
                                        <label for="recipient-name" class="col-form-label">Claim Type</label>
                                        <select  class="form-control mr-sm-2" name="city">
                                           <option selected="selected" value="Last 2 Months">Entertainment</option>
                                           <option value="Last 1 Month">XXXXXX</option>
                                           <option value="Last 3 Months">XXXXXXX</option>
                                        </select>
                                      </div>
                                      <div class="form-group" id="gx">
                                        <label for="message-text" class="col-form-label">Amount (RM)</label>  
                                        <input type="text" class="form-control" id="recipient-name">
                                      
                                      </div>
                                      <div class="form-group" id="gx">
                                        <label for="message-text" class="col-form-label">Receipt Date</label>
                                        <div class="tt">
                                        <input type="date" id="myDate">
                                        </div>
                                      </div>
                                      <div class="form-group" id="gx">
                                        <label for="message-text" class="col-form-label">Purpose</label>
                                        <textarea type="text" class="form-control" id="recipient-name"></textarea>
                                      </div>
                                      <div class="form-group" id="gx">
                                        <label for="message-text" class="col-form-label">Receipt Image</label>
                                        <div class="gh">
                                         <input type="file" id="filetag" >
                                         <div class="file">
                                         <img src="" id="preview" width="150" height="150">
                                         </div>
                                        </div>
                                      </div>
                                    </form>
                                    <div class="modal-footer1" >
                                      <button type="button" class="submit" data-dismiss="modal" align="right">Submit</button>
                                    </div>
                                      
                                    </div>
                                  </div>


               <div class="col-md-12">

                   <div class="card" id="ft">
                    <nav class="navbar navbar-expand-lg navbar-light" id="nav2">
                   
                        <a class="navbar-brand" href="#">Submitted Leaves</a>
                 
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls ="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                         <span class="navbar-toggler-icon"></span>
                        </button>

                     <div class="collapse navbar-collapse" id="navbarSupportedContent">
                      <ul class="navbar-nav mr-auto"> 
                      </ul>    
                      
                       <form class="form-inline my-2 my-lg-0">
                         <input class="form-control mr-sm-2" id="sa" type="search" placeholder="Search.." aria-label="Search">
                         <select  class="form-control mr-sm-2" id="location" name="city">
                           <option selected="selected" value="Last 2 Months">Show: Last 2 months</option>
                           <option value="Last 1 Month">Show: Last 1 month</option>
                           <option value="Last 3 Months">Show: Last 3 months</option>
                         </select>

                       </form>
                     </div>
                  </nav>


                  <div class="row" id="pw">
                
                            <div class="col-md-12" id="bor">
                              <p class="fs">PENDING APPROVAL</p>
                            </div>         
                            
                  </div>
                          

                   <div class="row" id="ow">
                          
                            <div class="col-md-6" id="ox">
                              <p id="st">Travel (RM50.00)</p>
                            </div>

                            <div class="col-md-6" id="ux" align="right">
                              <p class="fs">Submitted on 6 Dec</p>
                            </div>   
                          
                   </div>

                    <div class="row" id="ow">
                          
                            <div class="col-md-6" id="ox">
                              <p id="st">Entertainment (RM168.80)</p>
                            </div>

                            <div class="col-md-6" id="ux" align="right">
                              <p class="fs">Submitted on 9 Dec</p>
                            </div>   
                          
                   </div>



                    <div class="row" id="iw">
                
                            <div class="col-md-12" id="bor">
                              <p class="fs">HISTORY</p>
                            </div>         
                            
                   </div>

                    <div class="row" id="thrd">
                          
                            <div class="col-md-6" id="mx">
                              <p>Entertainment (RM100.00)</p>
                            </div>
                            <div class="col-md-6" id="kx" align="right">
                              <p>Approved on 26 Dec 2017</p>
                            </div>
                            
                   </div>


                   <div class="row" id="thrd">
                          
                            <div class="col-md-6" id="mx">
                              <p>Entertainment (RM100.00)</p>
                            </div>
                            <div class="col-md-6" id="kx" align="right">
                              <p>Approved on 26 Dec 2017</p>
                            </div>
                            
                   </div>


                  <div class="row" id="thrd">
                          
                            <div class="col-md-6" id="mx">
                              <p>Misc. (RM20.00)</p>
                            </div>
                            <div class="col-md-6" id="ix" align="right">
                              <p>Approved on 26 Dec 2017</p>
                            </div>
                            
                   </div>

                  <div class="row" id="thrd">
                          
                            <div class="col-md-6" id="mx">
                              <p>Entertainment (RM100.00)</p>
                            </div>
                            <div class="col-md-6" id="kx" align="right">
                              <p>Approved on 24 Nov 2017</p>
                            </div>
                            
                   </div>

                   </div>

                </div>

            </div>


      </div>
    </div>
  </div>






      <script>
      var fileTag = document.getElementById("filetag"),
      preview = document.getElementById("preview");
          
      fileTag.addEventListener("change", function() {
        changeImage(this);
      });

      function changeImage(input) {
        var reader;

      if (input.files && input.files[0]) {
      reader = new FileReader();

      reader.onload = function(e) {
      preview.setAttribute('src', e.target.result);
      }

          reader.readAsDataURL(input.files[0]);
        }
      }
     </script>



 <!--     Date -->

      <script>
      function myFunction() {
          document.getElementById("myDate").value = "2014-02-09";
      }
      </script>


           <!--   New Claim -->
      <script>
        // Get the modal
      var modale = document.getElementById('Modal');

      // Get the button that opens the modal
      var btn = document.getElementById("butn");

      // Get the <span> element that closes the modal
      var span = document.getElementsByClassName("close1")[0];

      // When the user clicks on the button, open the modal 
      btn.onclick = function() {
          modale.style.display = "block";
      }

      // When the user clicks on <span> (x), close the modal
      span.onclick = function() {
          modale.style.display = "none";
      }

      // When the user clicks anywhere outside of the modal, close it
      window.onclick = function(event) {
          if (event.target == modale) {
              modale.style.display = "none";
          }
      }

        </script>

 <!--    Clock In -->

        <script>
          // Get the modal
        var modal = document.getElementById('myModal');

        // Get the button that opens the modal
        var btn = document.getElementById("myBtn");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks on the button, open the modal 
        btn.onclick = function() {
            modal.style.display = "block";
        }

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

          </script>

      <!-- Bootstrap core JavaScript-->
    <script src="{{ asset('jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap.bundle.min.js') }}"></script>
    <!-- Core plugin JavaScript-->
    <script src="{{ asset('jquery-easing/jquery.easing.min.js') }}"></script>
    <!-- Page level plugin JavaScript-->
    <script src="{{ asset('chart/Chart.min.js') }}"></script>
    <script src="{{ asset('datatables/jquery.dataTables.js') }}"></script>
    <script src="{{ asset('datatables/dataTables.bootstrap4.js') }}"></script>



    <!-- Custom scripts for all pages-->
    <script src="{{ asset('js/sb-admin.min.js') }}"></script>


    <!-- Custom scripts for this page-->
    <script src="{{ asset('js/sb-admin-datatables.min.js') }}"></script>
    <script src="{{ asset('js/sb-admin-charts.min.js') }}"></script>
  </div>
</body>

</html>
