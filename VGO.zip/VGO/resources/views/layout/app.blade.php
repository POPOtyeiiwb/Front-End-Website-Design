<!Doctype html>
<html>
 <head>
 	<meta charset="utf-8">
 	<title>VGO-Instructor</title>
 	<title>@yield('page-title')</title>
    <link rel="icon" href="{!!asset('images/favicon-1.ico')!!}"/>
    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('css/back.css') }}" rel="stylesheet">
 </head>
 <body>
	<div class = "row backgroundimg">
       <div class="container-fluid">
 		  @yield('content')
 	   </div>  
 	</div>
 </body>

</html>