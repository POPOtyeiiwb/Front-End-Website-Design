<!Doctype html>
<html>
 <head>
 	<meta charset="utf-8">
 	<title>VGO-Instructor</title>
 	<title>@yield('page-title')</title>
    <link rel="icon" href="{!!asset('images/favicon-1.ico')!!}"/>
    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/back.css') }}" rel="stylesheet">
    <link href="{{ asset('css/signup.css') }}" rel="stylesheet">
 </head>
 <body>
 	<div class = "row backgroundimg">

 		<div class="container">
     <!--  @if(count($errors) > 0)
         @foreach($errors->all() as $error)
          <div class="alert alert-danger">
            {{$error}}
          </div>
          @endforeach
         @endif -->
 			 <div class="col-md-12">
 			 <div class = "card">  
 			 	<div class="btn-group">
                   <input class="backButton" type="button" value=''
                    onclick="window.location.href='http://localhost/VGO/public/welcome'"/>
                    <input class="loginButton" type="button" value='Login'
                    onclick="window.location.href='http://localhost/VGO/public/login'"/>

                   <!-- <button type="button" class="loginButton">Login</button> -->
                   <button type="button" class="signupButton">Sign Up</button>
        </div>
 			 	
 			 	<!-- <input class="loginButton" type="button" value=""> -->
 			 	<hr class="line"></hr>
 			 	{!! Form::open(['url' => 'signup/submit']) !!}
 	            <div class="form-group">
 		             {{Form::label('email','Email')}}
 		             {{Form::text('email','',['class' => 'form-control', 'placeholder' =>'Enter email address'])}}
 	            </div>
              <div class="form-group">
 		             {{Form::label('password','Password')}}
 		             {{Form::text('password','',['class' => 'form-control','placeholder' =>'Enter password'])}}
 	            </div>
              <div class="form-group">
                 {{Form::label('name','Name')}}
                 {{Form::text('name','',['class' => 'form-control','placeholder' =>'Enter name'])}}
              </div>
              <div class="form-group">
                 {{Form::label('contact','Contact')}}
                 {{Form::text('contact','',['class' => 'form-control','placeholder' =>'Enter contact'])}}
              </div>
              <div class="form-group">
                 {{Form::label('birthday','Birthday')}}
                 {{Form::text('birthday','',['class' => 'form-control','placeholder' =>'Enter birthday'])}}
              </div>
 	            <div class= "form-group">
                     {{Form::submit('Submit', ['class' => 'submit-button'])}}
              </div>

 	            {!! Form::close() !!}
 	           
 	         </div>
 	        </div>
        </div>
    </div>
 </body>

</html>