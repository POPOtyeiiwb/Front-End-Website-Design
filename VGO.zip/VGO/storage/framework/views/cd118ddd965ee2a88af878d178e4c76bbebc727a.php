<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">
            <h1 class="text-center text-white mb-4"><b>Welcome to VGO Aquatic</b></h1>
            <div class="row">
             
            <!-- form card login -->
                <div class="card">
                    <form>
                        <div class="row">
                          <div class="col-md-4">
                            <h2>Login</h2>
                          </div>
                          <div class="col-md-8">
                             <img src="<?php echo e(URL::asset('/images/login_vgo_logo.png')); ?>"alt="vgologo" height="80" width="110"/>
                          </div>
                        </div>
                        <div class= "form-group">
                            <button href="<?php echo e(route('home')); ?>" type="button" class="facebook-button">LOGIN WITH FACEBOOK</button>
                            <!-- <input type="button" class="facebook-button" value="LOGIN WITH FACEBOOK"/> -->
                        </div>
                        <div class= "form-group">
                            <input type="button" class="google-button" value="LOGIN WITH GOOGLE"/>
                        </div>
                        <div class= "form-group">
                            <input type="button" class="email-button" value="LOGIN WITH EMAIL"/>
                        </div>
                    </form>
                            
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?> 





<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>