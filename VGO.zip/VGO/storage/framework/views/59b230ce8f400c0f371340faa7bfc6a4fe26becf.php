<!Doctype html>
<html>
 <head>
 	<meta charset="utf-8">
 	<title>VGO-Instructor</title>
 	<title><?php echo $__env->yieldContent('page-title'); ?></title>
    <link rel="icon" href="<?php echo asset('images/favicon-1.ico'); ?>"/>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/back.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/login.css')); ?>" rel="stylesheet">
 </head>
 <body>
 	<div class = "row backgroundimg">

 		<div class="container">
 			 <div class="col-md-12">
 			 <div class = "card">
 			 	<div class="btn-group">
                   <input class="backButton" type="button" value=''
                    onclick="window.location.href='http://localhost/VGO/public/welcome'"/>
                   <button type="button" class="loginButton">Login</button>
                   <input class="signupButton" type="button" value='Sign Up'
                    onclick="window.location.href='http://localhost/VGO/public/signup'"/>
                </div>
 			 	
 			 	<!-- <input class="loginButton" type="button" value=""> -->
 			 	<hr class="line"></hr>
 			 	<?php echo Form::open(['url' => 'login/submit']); ?>

 	            <div class="form-group">
 		             <?php echo e(Form::label('email','Email')); ?>

 		             <?php echo e(Form::text('email','',['class' => 'form-control', 'placeholder' =>'Enter email address'])); ?>

 	            </div>
                <div class="form-group">
 		             <?php echo e(Form::label('password','Password')); ?>

 		             <?php echo e(Form::text('password','',['class' => 'form-control','placeholder' =>'Enter password'])); ?>

 	            </div>
                <div class= "form-group">
                     <?php echo e(Form::submit('Submit', ['class' => 'submit-button'])); ?>

                </div>
 	            <!-- <div class= "form-group">
                     <input type="button" class="submit-button" value="Submit"/> 
                </div> -->

 	            <?php echo Form::close(); ?>

 	           
 	         </div>
 	        </div>
        </div>
    </div>
 </body>

</html>