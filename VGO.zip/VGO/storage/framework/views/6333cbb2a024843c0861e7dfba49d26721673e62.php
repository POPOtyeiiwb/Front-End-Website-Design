<!Doctype html>
<html>
 <head>
 	<meta charset="utf-8">
 	<title>VGO-Instructor</title>
 	<title><?php echo $__env->yieldContent('page-title'); ?></title>
    <link rel="icon" href="<?php echo asset('images/favicon-1.ico'); ?>"/>
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/back.css')); ?>" rel="stylesheet">
 </head>
 <body>
	<div class = "row backgroundimg">
       <div class="container-fluid">
 		  <?php echo $__env->yieldContent('content'); ?>
 	   </div>  
 	</div>
 </body>

</html>