<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <title>VGO-Instructor</title>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">


  <!-- Bootstrap CSS CDN -->
  <link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
  
  <!-- Our Custom CSS -->
 <!--  <link rel="stylesheet" href="style2.css"> -->
  <!-- Scrollbar Custom CSS -->
  <link href="<?php echo e(asset('css/jquery.mCustomScrollbar.min.css')); ?>" rel="stylesheet">
  <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.min.css"> -->

</head>

<body>
  <div class="wrapper">
    <!-- Sidebar Holder -->
    <nav id="sidebar">
      <div class="sidebar-header">
       <div class="card">
         <img class = "logo" src="<?php echo e(URL::asset('/images/login_vgo_logo.png')); ?>" width="85" height="70" alt="vgologo">
       </div>
      </div>

      <ul class="list-unstyled components">
       
        <li class="active">
          <a href="#menu"><img class = "icon" src="<?php echo e(URL::asset('/images/home_ic.svg')); ?>" width="40" height="40" align="center" >Home</a>
        </li>
        <li>
          <a href="#menu"><img class = "icon" src="<?php echo e(URL::asset('/images/task_ic.svg')); ?>" width="40" height="40" align="center" >Assigned Tasks</a>
        </li>
        <li>
          <a href="#menu"><img class = "icon" src="<?php echo e(URL::asset('/images/duty_ic.svg')); ?>" width="40" height="40" align="center" >Duty Roster</a>
        </li>
        <li>
          <a href="#"><img class = "icon" src="<?php echo e(URL::asset('/images/student_ic.svg')); ?>" width="40" height="40" align="center" >Students</a>
        </li>
        <li>
          <a href="#"><img class = "icon" src="<?php echo e(URL::asset('/images/leave_ic.svg')); ?>" width="40" height="40" align="center" >Leave</a>
        </li>
        <li>
          <a href="#"><img class = "icon" src="<?php echo e(URL::asset('/images/claim_ic.svg')); ?>" width="40" height="40" align="center" >Claim</a>
        </li>
        <li>
          <a href="#"><img class = "icon" src="<?php echo e(URL::asset('/images/notice_ic.svg')); ?>" width="40" height="40" align="center" >Notice</a>
        </li>
        <li>
          <a href="#"><img class = "icon" src="<?php echo e(URL::asset('/images/calendar_ic.svg')); ?>" width="40" height="40" align="center" >VGO Calender</a>
        </li>
        <li>
          <a href="#"><img class = "icon" src="<?php echo e(URL::asset('/images/payroll_ic.svg')); ?>" width="40" height="40" align="center" >Payroll</a>
        </li>
        <li>
          <a href="#"><img class = "icon" src="<?php echo e(URL::asset('/images/feedback_ic.svg')); ?>" width="40" height="40" align="center" >Feedback</a>
        </li>
      </ul>
    </nav>
  </div>

    <!-- Page Content Holder -->
  <div id="content">
    

      
      <div class="header">


           <a id="sidebarCollapse" class="btn btn-info navbar-btn"><i class="fa fa-align-justify"></i></a>

           <!-- <button type="button" id="sidebarCollapse" class="btn btn-info navbar-btn"><i class="fa fa-align-justify"></i> 
           </button>-->
        <div class="header-right">
           <a class="clock" href="#clock">Clock In</a>
           <a class="notification" href="#notification">2</a>
           <a href="#about">About</a>
        </div>
      </div>
       
        <!--   <div class="col-md-4">
           <button type="button" id="sidebarCollapse" class="btn btn-info navbar-btn"><i class="fa fa-align-justify"></i>
            </button>
        </div> 
      
        <div class="col-md-4">
          
        </div>  -->
       <!--  <div class="col-md-4 pull-right" >
              
           <input class="clock " type="button" value="Clock In" onclick="window.location.href=' '"/>
           <input class="notification " type="button" value="2" onclick="window.location.href=' '"/>
            
        </div>  -->
          

   
       
      
    </nav>
  

<!-- <div class="container">
    <div class="row">
      <div class="col-sm-6 col-md-4 col-lg-3 mt-4">
         <div class="card" id="card2">
          <div class="card-block">
              <h2><img class = "icon" src="<?php echo e(URL::asset('/images/duty_green_ic.svg')); ?>" width="40" height="40" align="center" >Duty Roaster</h2>
          </div>
         </div>
      </div>
    </div>
  </div> -->
  <!-- jQuery CDN -->
 <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
  <!-- Bootstrap Js CDN -->
  <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
  <!-- jQuery Custom Scroller CDN -->
  <script src="<?php echo e(asset('js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
  <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script> -->

  <script type="text/javascript">
    $(document).ready(function() {


      $('#sidebarCollapse').on('click', function() {
        $('#sidebar, #content').toggleClass('active');
        $('.collapse.in').toggleClass('in');
        $('a[aria-expanded=true]').attr('aria-expanded', 'false');
      });
    });
  </script>
</body>

</html>