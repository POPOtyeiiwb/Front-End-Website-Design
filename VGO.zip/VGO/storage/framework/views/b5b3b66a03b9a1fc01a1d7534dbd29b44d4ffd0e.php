<!Doctype html>
<html>
 <head>
 	<meta charset="utf-8">
 	<title>VGO-Instructor</title>
 	<title><?php echo $__env->yieldContent('page-title'); ?></title>
    <link rel="icon" href="<?php echo asset('images/favicon-1.ico'); ?>"/>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
 </head>
 <body>
 	<div class = "row backgroundimg">
       <div class="container-fluid">

       	<h1>This is the first pages</h1>
 		
 	   </div>  
 	</div>
 </body>

</html>