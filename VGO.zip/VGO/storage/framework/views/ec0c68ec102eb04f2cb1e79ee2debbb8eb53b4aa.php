<?php $__env->startSection('content'); ?>


    <div class="container"> 
         <div class="row"> 
            <div class="col-md-12">
                <h1 class="text-center text-white mb-4"><b>Welcome to VGO Aquatic</b></h1>
                 <div class ="card">
                  
                      <form>
                        <img src="<?php echo e(URL::asset('/images/login_vgo_logo.png')); ?>"
                         alt="vgologo" width="110" height= "80" style="display: inline" />
                             <h2 style="display: inline">Login</h2>
                        <div class= "form-group">
                            <input class="facebook-button" type="button" value="LOGIN WITH FACEBOOK"
                             onclick="window.location.href='http://localhost/VGO/public/index'"/>
                        </div>
                        <div class= "form-group">
                             <input type="button" class="google-button" value="LOGIN WITH GOOGLE"/> 
                        </div>
                        <div class= "form-group">
                            <input class="email-button" type="button" value="LOGIN WITH EMAIL"
                             onclick="window.location.href='http://localhost/VGO/public/login'"/>
                        </div>
                      </form>
                 </div>
                
            </div>
         </div> 
    </div> 

<?php $__env->stopSection(); ?> 





<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>