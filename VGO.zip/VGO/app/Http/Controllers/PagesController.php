<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function getwelcome(){
    	return view('welcome');
    }


    public function gethome(){
    	return view('home');
    }

    public function getlogin(){
    	return view('login');
    }

    public function getsignup(){
    	return view('signup');
    }

     public function getindex(){
        return view('index');
    }


    public function getassignedtask(){
        return view('assignedtask');
    }

    public function getduty(){
        return view('duty');
    }

    public function getstudent(){
        return view('student');
    }

      public function getleave(){
        return view('leave');
    }

      public function getclaim(){
        return view('claim');
    }

     public function getnotice(){
        return view('notice');
    }

    public function getcalender(){
        return view('calender');
    }
   
    public function getpayroll(){
        return view('payroll');
    }

    public function getfeedback(){
        return view('feedback');
    }

    public function getstudent2(){
        return view('student2');
    }

    public function getcleaning(){
        return view('cleaning');
    }


}
