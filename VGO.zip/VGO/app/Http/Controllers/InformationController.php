<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Information;

class InformationController extends Controller
{
    public function submit(Request $request){

    	$this->validate($request, [

    		'email' => 'required',
    		'password' => 'required',
    		'name' => 'required',
    	    'contact' => 'required',
    	    'birthday' => 'required'
    	]);

    	//create new message
    	$information = new Information;
    	$information->email = $request->input('email');
    	$information->password = $request->input('password');
    	$information->name = $request->input('name');
    	$information->contact = $request->input('contact');
    	$information->birthday = $request->input('birthday');

    	//save Message
    	$information->save();

    	//Redirect

    	return redirect('/login');
    }
}
