<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/welcome', 'PagesController@getwelcome');


Route::get('/home', 'PagesController@gethome');

Route::get('/login', 'PagesController@getlogin');

Route::get('/signup', 'PagesController@getsignup');


Route::post('/signup/submit', 'InformationController@submit');









Route::get('/index', 'PagesController@getindex');


Route::get('/assignedtask', 'PagesController@getassignedtask');

Route::get('/duty', 'PagesController@getduty');


Route::get('/student', 'PagesController@getstudent');


Route::get('/leave', 'PagesController@getleave');

Route::get('/claim', 'PagesController@getclaim');



Route::get('/notice', 'PagesController@getnotice');


Route::get('/calender', 'PagesController@getcalender');

Route::get('/payroll', 'PagesController@getpayroll');

Route::get('/feedback', 'PagesController@getfeedback');

Route::get('/student2', 'PagesController@getstudent2');

Route::get('/cleaning', 'PagesController@getcleaning');





// Route::get('/welcome', function () {
//     return view('welcome');
// });