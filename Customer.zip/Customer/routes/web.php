<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/welcome', 'PagesController@getwelcome');


Route::get('/home', 'PagesController@gethome');

Route::get('/calender', 'PagesController@getcalender');

Route::get('/register', 'PagesController@getregister');

Route::get('/registration1', 'PagesController@getregistration1');

Route::get('/registration2', 'PagesController@getregistration2');

Route::get('/summary', 'PagesController@getsummary');

Route::get('/Attendance', 'PagesController@getAttendance');

Route::get('/badges', 'PagesController@getbadges');

Route::get('/class', 'PagesController@getclass');

Route::get('/member', 'PagesController@getmember');