<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PagesController extends Controller
{
    public function getwelcome(){
    	return view('welcome');
    }


    public function gethome(){
    	return view('home');
    }

    public function getclass(){
    	return view('class');
    }

    public function getmember(){
    	return view('member');
    }

     public function getregister(){
        return view('register');
    }


    public function getregistration1(){
        return view('registration1');
    }

    public function getregistration2(){
        return view('registration2');
    }

    public function getsummary(){
        return view('summary');
    }

      public function getAttendance(){
        return view('Attendance');
    }

      public function getbadges(){
        return view('badges');
    }

     public function getnotice(){
        return view('notice');
    }

    public function getcalender(){
        return view('calender');
    }
   
  
}
