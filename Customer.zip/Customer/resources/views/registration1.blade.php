<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>VGO Instructor</title>
  <link rel="icon" href="{!!asset('images/favicon-1.ico')!!}"/>
  <!-- Bootstrap core CSS-->
  <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet"> 
  <!-- Custom fonts for this template-->
  <link href="{{ asset('font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
  <!-- Page level plugin CSS-->
  <link href="{{ asset('datatables/dataTables.bootstrap4.css') }}" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="{{ asset('css/registration1.css') }}" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="http://localhost/Customer/public/home">
      <div class="card1" id="box">
         <img class = "logo" id="imag" src="{{URL::asset('/images/login_vgo_logo.png')}}" width="85" height="70" alt="vgologo">
       </div>
    </a>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
  

      <ul class="navbar-nav sidenav-toggler" >
      
      </ul> 
      <ul class="navbar-nav ml-auto">
        



        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle mr-lg-2" id="alertsDropdown" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img class = "pic2" src="{{URL::asset('/images/notification_ic.svg')}}" width="25" height="25" align="left" >
            <span class="aa">2</span>
          </a>
        </li>

        <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="profile" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                    <div class="banner">
                        <div class="nam1" >ADELINE WONG</div>
                    </div>
                    <div style="display:inline-block;">
                        
                       <img class="img-circle" src="{{URL::asset('/images/avatar-1.png')}}"  width="40" height="40" align="middle" > 
                    </div>

                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <div class="dropdown-header">Account</div>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-user"></i> Profile
                    </a>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-envelope"></i> Messages
                    </a>

                    <div class="dropdown-header">Settings</div>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-bell"></i> Notifications
                    </a>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-wrench"></i> Settings
                    </a>

                    <a href="#" class="dropdown-item" data-toggle="modal" data-target="#exampleModal">
                        <i class="fa fa-lock"></i> Logout
                    </a>
                </div>
            </li>
       
      </ul>
    </div>
  </nav>


   <div class="content-wrapper" style="overflow-y: scroll; height:200px;">

     <div class="container-fluid">

      <div class="row">
          <div class="leftcolumn">
            <div class="card">
              <h2>Swim School Registration</h2>
              <form action="/action_page.php" class="form1">
                <input type="checkbox" name="vehicle" value="Bike"><span class="lk"> I'm the member</span>
              </form>
              <p class="bodyhead">Member Information</p>
              <form action="/action_page.php" class="form2">
                  <div class="form-group">
                    <label for="name">Name </label>
                    <input type="name" class="form-control" id="email" placeholder="Enter name" name="email">
                  </div> 


                      
                  <div class="form-group">
                    <label for="numberRooms" id="birth">
                      Birthday <br>
                      <select name="type" id ="numberRooms"> 
                      <option value="1">1</option>
                      <option value="2">2</option>
                      </select> 
                    </label>
                    <label for="numberBeds" id="gender">
                      Gender<br>
                      <select name="type" id="numberBeds">
                      <option value="1">Female</option>
                      <option value="2">Male</option>
                      </select><br>
                    </label>
                  </div>

                  <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
                  </div>
                  <div class="form-group">
                    <label for="email">Contact Number</label>
                    <input type="email" class="form-control" id="email" placeholder="0123564589" name="email">
                  </div>
                  <div class="form-group">
                    <label for="email">Health Condition</label>
                    <input type="email" class="form-control" id="email" placeholder="0213546578" name="email">
                  </div>
              </form>

               <p class="bodyhead">Emergency Contact</p>

               <form action="/action_page.php" class="form2">
                  <div class="form-group">
                    <label for="name">Emergency Contact Name</label>
                    <input type="name" class="form-control" id="email" placeholder="Enter name" name="email">
                  </div>   


                   <div class="form-group" >
                    <label for="numberBeds" class="col-form-label">Relationship</label>
                    <select  class="form-control mr-sm-2" name="type" >
                       <option selected="selected" value="Last 2 Months">Sister</option>
                       <option value="Last 1 Month">Father</option>
                       <option value="Last 3 Months">Mother</option>
                    </select>
                  </div>       

          

                  <div class="form-group">
                    <label for="email">Contact Number</label>
                    <input type="email" class="form-control" id="email" placeholder="0123564589" name="email">
                  </div>
              </form>

              <form action="http://localhost/Customer/public/registration2" method="get">
                  <button class="canc" formaction="http://localhost/Customer/public/register">Cancel</button>
                  <button class="btn" formaction="http://localhost/Customer/public/registration2">Next</button>
                  
              </form> 

            </div>
            
          </div>

          <div class="rightcolumn">
            <div class="card3">
              <p class="pack">PADI Learn to Swim</p>
              <p class="price">Every Monday at 9:00 AM</p>
              <p class="price1">Starting 8 Jan 2018</p>

               <div class="row" id="thrd3">
                          
                  <div class="col-md-8" id="mx">
                    <p>First Month Fee</p>
                  </div>
                  <div class="col-md-4" id="ix" >
                    <p>RM50.00</p>
                  </div>
      
               </div>

               <div class="row" id="thrd3">
    
                  <div class="col-md-8" id="mx">
                    <p>New Member Deposit</p>
                  </div>
                  <div class="col-md-4" id="ix" >
                     <p>RM200.00</p>
                  </div>
      
               </div>

               <div class="row" id="thrdd">
    
                  <div class="col-md-8" id="px">
                    <p>GST 6%</p>
                  </div>
                  <div class="col-md-4" id="ix" >
                      <p>RM200.00</p>
                  </div>
      
               </div>

               <div class="row" id="thrddd">
    
                  <div class="col-md-8" id="mx">
                    <p>Total</p>
                  </div>
                  <div class="col-md-4" id="ix" >
                      <p>RM265.00</p>
                  </div>
      
               </div>

            </div>
          </div>



     </div>


   </div>
















    <script>
      // Get the modal
    var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on the button, open the modal 
    btn.onclick = function() {
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    </script>









    <!-- Bootstrap core JavaScript-->
    <script src="{{ asset('jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap.bundle.min.js') }}"></script>
    <!-- Core plugin JavaScript-->
    <script src="{{ asset('jquery-easing/jquery.easing.min.js') }}"></script>
    <!-- Page level plugin JavaScript-->
    <script src="{{ asset('chart/Chart.min.js') }}"></script>
    <script src="{{ asset('datatables/jquery.dataTables.js') }}"></script>
    <script src="{{ asset('datatables/dataTables.bootstrap4.js') }}"></script>



    <!-- Custom scripts for all pages-->
    <script src="{{ asset('js/sb-admin.min.js') }}"></script>


    <!-- Custom scripts for this page-->
    <script src="{{ asset('js/sb-admin-datatables.min.js') }}"></script>
    <script src="{{ asset('js/sb-admin-charts.min.js') }}"></script>
  </div>
</body>

</html>