<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>VGO-Customer</title>
   <link rel="icon" href="<?php echo asset('images/favicon-1.ico'); ?>"/>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet"> 
  <!-- Custom fonts for this template-->
  <link href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
  <!-- Page level plugin CSS-->
  <link href="<?php echo e(asset('datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo e(asset('css/register.css')); ?>" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="http://localhost/Customer/public/home">
      <div class="card1" id="box">
         <img class = "logo" id="imag" src="<?php echo e(URL::asset('/images/login_vgo_logo.png')); ?>" width="85" height="70" alt="vgologo">
       </div>
    </a>

      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
       


      <ul class="navbar-nav sidenav-toggler" >
      
      </ul> 
      <ul class="navbar-nav ml-auto">
    
        <li class="nav-item dropdown" id="notify">
          <a class="nav-link dropdown-toggle mr-lg-2" id="alertsDropdown" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img class = "pic2" src="<?php echo e(URL::asset('/images/notification_ic.svg')); ?>" width="25" height="25" align="left" >
            <span class="aa">2</span>
          </a>
        </li>

        <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" id="profile" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                    <div class="banner">
                        <div class="nam1" >ADELINE WONG</div>
                    </div>
                    <div style="display:inline-block;">
                        
                       <img class="img-circle" src="<?php echo e(URL::asset('/images/avatar-1.png')); ?>"  width="40" height="40" align="middle" > 
                    </div>

                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <div class="dropdown-header">Account</div>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-user"></i> Profile
                    </a>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-envelope"></i> Messages
                    </a>

                    <div class="dropdown-header">Settings</div>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-bell"></i> Notifications
                    </a>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-wrench"></i> Settings
                    </a>

                    <a href="#" class="dropdown-item" data-toggle="modal" data-target="#exampleModal">
                        <i class="fa fa-lock"></i> Logout
                    </a>
                </div>
          </li>

       </ul>
    </div>
  </nav>


   <div class="content-wrapper" style="overflow-y: scroll; height:200px;">
    <div class="container-fluid">
    

        <div class="row">
          <div class="leftcolumn">
            <div class="card">
              <h2>PADI Learn to Swim</h2>
              <h3>Swim Package</h3>
              <p class="bodyhead">What package is this</p>
              <p class="bodypara">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind the texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.<br> <br>

              Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind the texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. </p>

              <h4>Who can join</h4>
              <p class="detail">Children age between 6 to 12 years old</p>


              <h4>Package type</h4>
              <p class="detail">12 swimming lessons (4 lessons a month) </p>

              <h4>Available in</h4>
              <p class="detail1">VGO Aquatic Centre</p>
              <p class="detail1">Desa Park City</p>

            </div>
            
          </div>
          <div class="rightcolumn">
            <div class="card3">
              <img class="child" src="<?php echo e(URL::asset('/images/images.jpg')); ?>" alt="John" style="width:100%">
              <p class="pack"><b>RM 50</b> per month</p>
              <p class="price">109 people bought this</p>
            </div>


            <div class="card">
              <h5>When do you want to go?</h5>


               <div class="row" id="thrd">
                          
                            <div class="col-md-6" id="mx">
                              <p>Every Monday</p>
                            </div>
                            <div class="col-md-6" id="kx">
                              <button id="butn1"><span class="aw">See Time Slots</span></button>

                                <!-- The Modal -->
                                <div id="myModal" class="modal">

                                  <!-- Modal content -->
                                  <div class="modal-content">
                                    <div class="close">
                                     <button class="exit" align="right">&times; Close</button>
                                    </div>
                                    <p class="title">What time do you prefer?</p>
                                    <p class="hd">Every Monday at </p>
                                     <div class="row" id="thrd3">
                          
                                        <div class="col-md-6" id="mx">
                                          <p>9:00 AM</p>
                                        </div>
                                        <div class="col-md-6" id="ix" >
                                          <a class="nav-link" id="butn3" href="http://localhost/Customer/public/registration1">
                                            <span class="aw">Choose</span>
                                          </a>

                                        </div>
                            
                                     </div>

                                     <div class="row" id="thrd3">
                          
                                        <div class="col-md-6" id="mx">
                                          <p>10:00 AM</p>
                                        </div>
                                        <div class="col-md-6" id="ix" >
                                           <a class="nav-link" id="butn3" href="http://localhost/Customer/public/registration1">
                                            <span class="aw">Choose</span>
                                          </a>
                                        </div>
                            
                                     </div>

                                     <div class="row" id="thrd3">
                          
                                        <div class="col-md-6" id="mx">
                                          <p>11:00 AM</p>
                                        </div>
                                        <div class="col-md-6" id="ix" >
                                          <a class="nav-link" id="butn3" href="http://localhost/Customer/public/registration1">
                                            <span class="aw">Choose</span>
                                          </a>
                                        </div>
                            
                                     </div>

                                     <div class="row" id="thrd3">
                          
                                        <div class="col-md-6" id="mx">
                                          <p>3:00 PM</p>
                                        </div>
                                        <div class="col-md-6" id="ix" >
                                           <a class="nav-link" id="butn3" href="http://localhost/Customer/public/registration1">
                                            <span class="aw">Choose</span>
                                          </a>
                                        </div>
                            
                                     </div>

                                     <div class="row" id="thrd3">
                          
                                        <div class="col-md-6" id="mx">
                                          <p>4:00 PM</p>
                                        </div>
                                        <div class="col-md-6" id="ix" >
                                           <a class="nav-link" id="butn3" href="http://localhost/Customer/public/registration1">
                                            <span class="aw">Choose</span>
                                          </a>
                                        </div>
                            
                                     </div>

                                     <div class="row" id="thrd4">
                          
                                        <div class="col-md-6" id="mx">
                                          <p>5:00 PM</p>
                                        </div>
                                        <div class="col-md-6" id="ix" >
                                          <a class="nav-link" id="butn3" href="http://localhost/Customer/public/registration1">
                                            <span class="aw">Choose</span>
                                          </a>
                                        </div>
                            
                                     </div>

                                  </div>

                                </div>

                            </div>
                            
                   </div>


                  <div class="row" id="thrd">
                          
                            <div class="col-md-6" id="mx">
                              <p>Every Tuesday</p>
                            </div>
                            <div class="col-md-6" id="kx" >
                              <button id="butn1"><span class="aw">See Time Slots</span></button>
                            </div>
                            
                   </div>

                  <div class="row" id="thrd">
                          
                            <div class="col-md-6" id="mx">
                              <p>Every Thursday</p>
                            </div>
                            <div class="col-md-6" id="kx" >
                              <button id="butn1"><span class="aw">See Time Slots</span></button>
                            </div>
                            
                  </div>

                   <div class="row" id="thrd">
                          
                            <div class="col-md-6" id="mx">
                              <p>Every Friday</p>
                            </div>
                            <div class="col-md-6" id="kx">
                              <button id="butn1"><span class="aw">See Time Slots</span></button>
                            </div>
                            
                  </div>

                   <div class="row" id="thrd">
                          
                            <div class="col-md-6" id="mx">
                              <p>Every Saturday</p>
                            </div>
                            <div class="col-md-6" id="kx" >
                              <button id="butn1"><span class="aw">See Time Slots</span></button>
                            </div>
                            
                  </div>

                   <div class="row" id="thrd1">
                          
                            <div class="col-md-6" id="mx">
                              <p>Every Sunday</p>
                            </div>
                            <div class="col-md-6" id="kx">
                              <button id="butn1"><span class="aw">See Time Slots</span></button>
                            </div>
                            
                  </div>

              
            </div>
            
          </div>
        </div>

    </div>
  </div>
                 













<script type="text/javascript">
//<![CDATA[
window.onload = init;
function init() {
  document.months.mStr.options[new Date().getMonth()].selected = true;
}

//]]>
</script>


<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("butn1");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("exit")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>



























    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('jquery-easing/jquery.easing.min.js')); ?>"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo e(asset('chart/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/dataTables.bootstrap4.js')); ?>"></script>



    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('js/sb-admin.min.js')); ?>"></script>


    <!-- Custom scripts for this page-->
    <script src="<?php echo e(asset('js/sb-admin-datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sb-admin-charts.min.js')); ?>"></script>
  </div>
</body>

</html>