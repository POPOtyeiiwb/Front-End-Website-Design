<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>VGO-Customer</title>
   <link rel="icon" href="<?php echo asset('images/favicon-1.ico'); ?>"/>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet"> 
  <!-- Custom fonts for this template-->
  <link href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
  <!-- Page level plugin CSS-->
  <link href="<?php echo e(asset('datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo e(asset('css/home.css')); ?>" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="http://localhost/Customer/public/home">
      <div class="card" id="box">
         <img class = "logo" id="imag" src="<?php echo e(URL::asset('/images/login_vgo_logo.png')); ?>" width="85" height="70" alt="vgologo">
       </div>
    </a>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item1" data-toggle="tooltip" data-placement="right" title="Home">
          <a class="nav-link" href="http://localhost/Customer/public/home">
            <img class = "icon" src="<?php echo e(URL::asset('/images/home_ic.svg')); ?>" width="20" height="20" align="center" >
            <span class="nav-link-text">Home</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Assigned Tasks">
          <a class="nav-link" href="">
            <img class = "icon" src="<?php echo e(URL::asset('/images/notice_ic.svg')); ?>" width="20" height="20" align="center" >
            <span class="nav-link-text">Notice</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Duty Roster">
          <a class="nav-link" href="">
            <img class = "icon" src="<?php echo e(URL::asset('/images/package_ic.svg')); ?>" width="20" height="20" align="center" >
            <span class="nav-link-text">Packages</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Students">
          <a class="nav-link" href="">
            <img class = "icon" src="<?php echo e(URL::asset('/images/member_ic.svg')); ?>" width="20" height="20" align="center" >
            <span class="nav-link-text">Members</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Leave">
          <a class="nav-link" href="">
            <img class = "icon" src="<?php echo e(URL::asset('/images/payment_ic.svg')); ?>" width="20" height="20" align="center" >
            <span class="nav-link-text">My Payment</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Claim">
          <a class="nav-link" href="">
            <img class = "icon" src="<?php echo e(URL::asset('/images/classcredit_ic.svg')); ?>" width="20" height="20" align="center" >
            <span class="nav-link-text">Class Credit</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Notice">
          <a class="nav-link" href="http://localhost/Customer/public/calender#">
            <img class = "icon" src="<?php echo e(URL::asset('/images/calendar_ic.svg')); ?>" width="20" height="20" align="center" >
            <span class="nav-link-text">VGO Calender</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="VGO Calender">
          <a class="nav-link" href="">
            <img class = "icon" src="<?php echo e(URL::asset('/images/feedback_ic.svg')); ?>" width="20" height="20" align="center" >
            <span class="nav-link-text">Feedback</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Payroll">
          <a class="nav-link" href="">
            <img class = "icon" src="<?php echo e(URL::asset('/images/contactus_ic.svg')); ?>" width="20" height="20" align="center" >
            <span class="nav-link-text">Contact Us</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Feedback">
          <a class="nav-link" href="">
            <img class = "icon" src="<?php echo e(URL::asset('/images/aboutus_ic.svg')); ?>" width="20" height="20" align="center" >
            <span class="nav-link-text">About Us</span>
          </a>
        </li>
      </ul>


      <ul class="navbar-nav sidenav-toggler" >
      
      </ul> 
      <ul class="navbar-nav ml-auto">
       

        <li class="nav-item dropdown" id="notify">
          <a class="nav-link dropdown-toggle mr-lg-2" id="alertsDropdown" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <img class = "pic2" src="<?php echo e(URL::asset('/images/notification_ic.svg')); ?>" width="25" height="25" align="left" >
            <span class="aa">2</span>
          </a>
        </li>

        <li class="nav-item dropdown">
                 <a class="nav-link dropdown-toggle" id="profile" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                    <div class="banner">
                        <div class="nam1" >ADELINE WONG</div>
                    </div>
                    <div style="display:inline-block;">
                        
                       <img class="img-circle" src="<?php echo e(URL::asset('/images/avatar-1.png')); ?>"  width="40" height="40" align="middle" > 
                    </div>

                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <div class="dropdown-header">Account</div>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-user"></i> Profile
                    </a>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-envelope"></i> Messages
                    </a>

                    <div class="dropdown-header">Settings</div>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-bell"></i> Notifications
                    </a>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-wrench"></i> Settings
                    </a>

                    <a href="#" class="dropdown-item" data-toggle="modal" data-target="#exampleModal">
                        <i class="fa fa-lock"></i> Logout
                    </a>
                </div>
            </li>
      </ul>
    </div>
  </nav>


   <div class="content-wrapper" style="overflow-y: scroll; height:250px;">
    <div class="container-fluid">
      <div class="content">

               <div class="row" id="main">

                 <div class="col-md-6" id="title">
                   <h1> Hi, Michael Chin </h1>
                   <p> wishing you a happy new year! </p>
                 </div>


                 <div class="col-md-6" id="but">
                   <div class = "row">
                     <div class="col-6">
                        <button id="butn"><img class = "icon" src="<?php echo e(URL::asset('/images/star.png')); ?>" width="20" height="20" align="left"><span class= "aww" >Class Credit : 1</span></button>
                     </div>
                     <div class="col-6">
                        <button id="butn"><img class = "icon" src="<?php echo e(URL::asset('/images/dollar-symbol.png')); ?>" width="20" height="20" align="left" ><span class= "aww">Make Payment</span></button>
                     </div>
                   </div>
                 </div>

               </div>


               <div class="row mt-2">  

                <div class="container">

                   <div class="col-md-12">
                    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" >
                    <ol class="carousel-indicators">
                      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner"  role="listbox" style=" height: 400px !important;">
                      <div class="carousel-item active">
                        <img class="d-block w-100" src="<?php echo e(URL::asset('/images/young-boy-swimming.jpg')); ?>" height="400px" alt="First slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block w-100" src="<?php echo e(URL::asset('/images/swimming.jpg')); ?>" height="400px" alt="Second slide">
                      </div>
                      <div class="carousel-item">
                        <img class="d-block w-100" src="<?php echo e(URL::asset('/images/gym.jpg')); ?>" height="400px" alt="Third slide">
                      </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                </div>
              </div>


               </div>

               <div class="row mt-2">

                   <div class="col-md-6">
                    <div class="card" id="secon">
                        <div class="card-header" >
                           <img class = "icon" src="<?php echo e(URL::asset('/images/student_green_ic.svg')); ?>" width="20" height="20" align="center">
                            Chin Hong Wei

                            <button
                             class="btn" onclick="window.location.href='http://localhost/VGO/public/leave'">Active<img class = "ion" src="" width="10" height="10" ></button>
                        </div>

                        <div class="card-body" id="cd">
                  

                          <div class="row" id="rw">
                            <div class="col-md-12" id="mx" align="center">
                              <img class = "ion" src="<?php echo e(URL::asset('/images/baby.jpg')); ?>" width="100" height="100">
                            </div>
                                   
                         </div>
                          

                   <div class="row" id="ww">
                          
                           <div class="col-md-6" id="vx">
                              <p class="ps">PACKAGE</p>
                              <p class="hs">PADI Stroke School</p>
                            </div>
                            <div class="col-md-6" id="px">
                              <p class="os">LEVEL</p>
                              <p class="ys">Red</p>
                            </div>

                   </div>

                    <div class="row" id="third1">
                          
                            <div class="col-md-12" id="mx">
                              <p class="ps1">CLASS SCHEDULE</p>
                              <p class="hs1">Every Saturday 9:00 am</p>
                            </div>
                            
                   </div>

                   <div class="row" id="third2">
                          
                            <div class="col-md-12" id="mx">
                              <p class="ps1">CLASS PROGRESS</p>
                              <p class="hs1">70% to Yellow Level</p>
                            </div>
                            
                   </div>

                   <div class="row" id="third2">
                          
                            <div class="col-md-12" id="mx">
                              <p class="ps1">PAYMENT</p>
                              <p class="hs1">Paid for Jan 2018</p>
                            </div>
                            
                   </div>

                    <div class="row" id="third3">
                          
                            <div class="col-md-12" id="mx" align="center">
                              <button
                              class="button2" onclick="window.location.href='http://localhost/Customer/public/summary'">View Details</button>
                              
                            </div>
                            
                   </div>


                  </div>
                </div>
               </div>

                   <div class="col-md-6">

                    <div class="card" id="secon">
                        <div class="card-header" >
                           <img class = "icon" src="<?php echo e(URL::asset('/images/student_green_ic.svg')); ?>" width="20" height="20" align="center">
                            Chin Hong Wei

                            <button
                             class="btn" onclick="window.location.href='http://localhost/VGO/public/leave'">Active<img class = "ion" src="" width="10" height="10" ></button>
                        </div>

                        <div class="card-body" id="cd">
                  

                          <div class="row" id="rw">
                            <div class="col-md-12" id="mx" align="center">
                              <img class = "ion" src="<?php echo e(URL::asset('/images/baby.jpg')); ?>" width="100" height="100">
                            </div>
                                   
                         </div>
                          

                           <div class="row" id="ww">
                                  
                                   <div class="col-md-6" id="vx">
                                      <p class="ps">PACKAGE</p>
                                      <p class="hs">PADI Stroke School</p>
                                    </div>
                                    <div class="col-md-6" id="px">
                                      <p class="os">LEVEL</p>
                                      <p class="ys">Red</p>
                                    </div>

                           </div>

                            <div class="row" id="third1">
                                  
                                    <div class="col-md-12" id="mx">
                                      <p class="ps1">CLASS SCHEDULE</p>
                                      <p class="hs1">Every Saturday 9:00 am</p>
                                    </div>
                                    
                           </div>

                           <div class="row" id="third2">
                                  
                                    <div class="col-md-12" id="mx">
                                      <p class="ps1">CLASS PROGRESS</p>
                                      <p class="hs1">70% to Yellow Level</p>
                                    </div>
                                    
                           </div>

                           <div class="row" id="third2">
                                  
                                    <div class="col-md-12" id="mx">
                                      <p class="ps1">PAYMENT</p>
                                      <p class="hs1">Paid for Jan 2018</p>
                                    </div>
                                    
                           </div>

                            <div class="row" id="third3">
                                  
                                    <div class="col-md-12" id="mx" align="center">
                                      <button
                                      class="button2" onclick="window.location.href=">View Details</button>
                                      
                                    </div>
                                    
                           </div>
                     </div>

                     
                   </div>
               </div>
            </div>




             <div class="row mt-2">

                 <div class="col-md-12">

                    <div class="card" id="rt">

                          <div class="card-header">
                               <img class = "icon" src="<?php echo e(URL::asset('/images/warning.png')); ?>" width="18" height="18" align="center">
                               Notice <button class="btn" onclick="window.location.href=">See All<img class = "ion" src="<?php echo e(URL::asset('/images/arrowright_ic.svg')); ?>" width="10" height="10" ></button>
                          </div>


                          <div class="card-body" id="bd">

                            <div class="row" id="nw">
                          
                                <div class="col-md-6" id="mx">

                                  <a class="nav-link" href=""><span class="aw">Wish you all a Happy New Year!</span></a>

                                </div>
                                <div class="col-md-6" id="tx" align="right">
                                  <p>28 Dec</p>
                                </div>
                            </div>

                            <div class="row" id="nw">
                    
                                <div class="col-md-6" id="mx">
                                  <a class="nav-link" href=""><span class="aw">VGO Aquatic close on 1st of January 2018</span></a>
                                </div>
                                <div class="col-md-6" id="tx" align="right">
                                  <p>20 Dec</p>
                                </div>
                            </div>


                            <div class="row" id="nnw">  

                                <div class="col-md-6" id="mx">
                                  <a class="nav-link" href=""><span class="aw">Annual Instructor Briefing</span></a>
                                </div>
                                <div class="col-md-6" id="tx" align="right">
                                  <p>3 Dec</p>

                                </div>
                            </div>

                          </div>
                    </div>

                  </div>    
                </div>



                 <div class="row mt-2">

                  <div class="col-md-6">
                    <div class="card" id="secon">

                        <img class="child" src="<?php echo e(URL::asset('/images/images.jpg')); ?>" alt="John" style="width:100%">
                          <h2>PADI Learn to Swim</h2>
                          <p class="pack">Swim Package</p>
                          <p class="price">RM 180 / Month</p>



                          <button class="regbtn" onclick="window.location.href='http://localhost/Customer/public/register'">Register Now</button>
                    </div>
                  </div>

                      <div class="col-md-6">
                        <div class="card" id="secon">

                          <img class="child" src="<?php echo e(URL::asset('/images/swim.png')); ?>" alt="John" style="width:100%">
                          <h2>Advance Assessment</h2>
                          <p class="pack">Swim Package</p>
                          <p class="price">RM 10</p>



                          <button class="regbtn" onclick="window.location.href=">Register Now</button>
                        </div>
                        
                      </div>
              </div>




                 <div class="row mt-2">

                  <div class="col-md-6">
                     <div class="card" id="secon">

                        <img class="child" src="<?php echo e(URL::asset('/images/gym-2.jpg')); ?>" alt="John" style="width:100%">
                          <h2>GYM 3-Months (Unlimited Access)</h2>
                          <p class="pack">Gym Package</p>
                          <p class="price">RM 388 </p>



                          <button class="regbtn" onclick="window.location.href=">Register Now</button>
                    </div>
                  </div>

                      <div class="col-md-6">
                        
                      </div>
              </div>




                           




      </div>
    </div>
  </div>





      <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('jquery-easing/jquery.easing.min.js')); ?>"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo e(asset('chart/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/dataTables.bootstrap4.js')); ?>"></script>



    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('js/sb-admin.min.js')); ?>"></script>


    <!-- Custom scripts for this page-->
    <script src="<?php echo e(asset('js/sb-admin-datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sb-admin-charts.min.js')); ?>"></script>
  </div>
</body>

</html>
