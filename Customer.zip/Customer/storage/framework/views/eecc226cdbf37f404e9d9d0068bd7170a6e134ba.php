<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>VGO-Customer</title>
  <link rel="icon" href="<?php echo asset('images/favicon-1.ico'); ?>"/>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo e(asset('css/bootstrap2.min.css')); ?>" rel="stylesheet"> 
  <!-- Custom fonts for this template-->
  <link href="<?php echo e(asset('font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
  <!-- Page level plugin CSS-->
  <link href="<?php echo e(asset('datatables/dataTables.bootstrap4.css')); ?>" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo e(asset('css/summary.css')); ?>" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="http://localhost/Customer/public/home">
         <img class = "logo" id="imag" src="<?php echo e(URL::asset('/images/login_vgo_logo.png')); ?>" width="70" height="60" alt="vgologo">
       
    </a>

    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item1" data-toggle="tooltip" data-placement="right" title="Home">
          <a class="nav-link" href="http://localhost/Customer/public/summary">
            <span class="nav-link-text">Summary</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Assigned Tasks">
          <a class="nav-link" href="http://localhost/Customer/public/Attendance">
            <span class="nav-link-text">Attendance</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Duty Roster">
          <a class="nav-link" href="http://localhost/Customer/public/badges">
            <span class="nav-link-text">Levels & Badges</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Students">
          <a class="nav-link" href="http://localhost/Customer/public/class">
            <span class="nav-link-text">Class Progress</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Leave">
          <a class="nav-link" href="http://localhost/Customer/public/member">
            <span class="nav-link-text">Edit Member Profile</span>
          </a>
        </li>
      </ul>



      <ul class="navbar-nav sidenav-toggler" >
      
      </ul> 
      <ul class="navbar-nav ml-auto">

        <li class="nav-item dropdown">
                 <a class="nav-link dropdown-toggle" id="profile" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">        
                       <img class="img-circle" src="<?php echo e(URL::asset('/images/avatar-1.png')); ?>"  width="40" height="40" align="middle" > 
                   

                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <div class="dropdown-header">Account</div>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-user"></i> Profile
                    </a>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-envelope"></i> Messages
                    </a>

                    <div class="dropdown-header">Settings</div>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-bell"></i> Notifications
                    </a>

                    <a href="#" class="dropdown-item">
                        <i class="fa fa-wrench"></i> Settings
                    </a>

                    <a href="#" class="dropdown-item" data-toggle="modal" data-target="#exampleModal">
                        <i class="fa fa-lock"></i> Logout
                    </a>
                </div>
            </li>
    
      </ul>
    </div>
  </nav>


   <div class="content-wrapper" style="overflow-y: scroll; height:200px;">


    <div class="row">
                <div class="col-md-12">
                   <div class="card" id="ft">
                     <div class="row" id="rw">
                            <div class="col-md-2" id="mx">
                              <img class = "ion" src="<?php echo e(URL::asset('/images/baby.jpg')); ?>" width="100" height="100"  >
                            </div>
                            <div class="col-md-3" id="kx">
                              <p class="fs">Chin Hong Wei</p>
                              <p class="ss">Active</p>
                            </div>
                            <div class="col-md-3" id="vx">
                              <p class="ps">PACKAGE</p>
                              <p class="hs">PADI Stroke School</p>
                            </div>
                            <div class="col-md-4" id="px">
                              <p class="os">LEVEL</p>
                              <p class="ys">Red</p>
                            </div>
                            
                            
                  </div>
                          

                   <div class="row" id="ww">
                          
                            <div class="col-md-3" id="mx">
                              <p>ATTENDANCE</p>
                            </div>
                            <div class="col-md-5" id="kx">
                              <p>3/4 in December 2018</p>
                            </div>
                            <div class="col-md-3" id="bar" >
                            <div class="progress">
                               <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="50"
                                  aria-valuemin="0" aria-valuemax="100" style="width:75%">
                               
                               </div>
                            </div>
                            </div>
                            <div class="col-md-1" id="ll">
                              75%   
                            </div>
                   </div>

                    <div class="row" id="third">
                          
                            <div class="col-md-3" id="mx">
                              <p>PAYMENT</p>
                            </div>
                            <div class="col-md-5" id="kx">
                              <p>Paid for Jan 2018 (RM50.00 Monthly)</p>
                            </div>
                            <div class="col-md-3" id="bar" >
                            <div class="progress">
                               <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="50"
                                  aria-valuemin="0" aria-valuemax="100" style="width:70%">
                               
                               </div>
                            </div>
                            </div>
                            <div class="col-md-1" id="ll">
                              70%   
                            </div>
                   </div>



                  <div class="row" id="third">
                          
                            <div class="col-md-3" id="mx">
                              <p>CLASS PROGRESS</p>
                            </div>
                            <div class="col-md-5" id="kx">
                              <p>Body Position and Air Recovery</p>
                            </div>
                            <div class="col-md-4" id="bar" >
                               
                              <input class="secbutn" type="submit" name = "" value="MAKE PAYMENT" >

                            </div>
                            
                   </div>

                    <div class="row" id="third3">
                          
                            <div class="col-md-3" id="mx">
                              <p>PACKAGE VALIDITY</p>
                            </div>
                            <div class="col-md-5" id="kx">
                              <p>Until 31 April 2018</p>
                            </div>
                            <div class="col-md-4" id="bar" >
                               
                              <input class="secbutn2" type="submit" name = "" value="TERMINATE/CANCEL PACKAGE" >

                            </div>
                            
                   </div>
                 </div>

                </div>
            </div>



            <!--   3nd table -->


             <div class="row mt-4">
              <div class="col-md-12">
              <div class="card" id="ft">

                  <div class="row" id="ro">
                            <div class="col-md-12" id="yx">
                              <p><b>Class Schedule: January 2018</b></p>
                            </div>
                            
                  </div>
                          
                  <div class="row" id="rr">
                            <div class="col-md-3" id="hx">
                              <p>VGO AQUATIC KEPONG</p>
                            </div>
                            <div class="col-md-6" id="kx">
                              <p>9:00am - Saturday, 6th Jan 2018</p>
                            </div>
                            <div class="col-md-3" >
                              <input class="secbutn" type="submit" name ="" value="RESCHEDULE" >
                            </div>
                            
                  </div>

                   <div class="row" id="rr">
                            <div class="col-md-3" id="hx">
                              <p>VGO AQUATIC KEPONG</p>
                            </div>
                            <div class="col-md-6" id="kx">
                              <p>9:00am - Saturday, 13th Jan 2018</p>
                            </div>
                            <div class="col-md-3" >
                              <input class="secbutn" type="submit" name ="" value="RESCHEDULE" >
                            </div>
                            
                  </div>

                   <div class="row" id="rr">
                            <div class="col-md-3" id="hx">
                              <p>VGO AQUATIC KEPONG</p>
                            </div>
                            <div class="col-md-6" id="kx">
                              <p>9:00am - Saturday, 20th Jan 2018</p>
                            </div>
                            <div class="col-md-3" >
                              <input class="secbutn" type="submit" name ="" value="RESCHEDULE" >
                            </div>
                            
                  </div>

                  <div class="row" id="rr">
                            <div class="col-md-3" id="hx">
                              <p>VGO AQUATIC KEPONG</p>
                            </div>
                            <div class="col-md-6" id="kx">
                              <p>9:00am - Saturday, 27th Jan 2018</p>
                            </div>
                            <div class="col-md-3" >
                              <input class="secbutn" type="submit" name ="" value="RESCHEDULE" >
                            </div>
                            
                  </div>

                  <div class="row" id="rr">
                            <div class="col-md-3" id="hx">
                              <p>VGO AQUATIC KEPONG</p>
                            </div>
                            <div class="col-md-6" id="kx">
                              <p>4:00am - Sunday, 28th Jan 2018</p>
                            </div>
                            <div class="col-md-3" id="uu">
                               <p >REPLACEMENT CLASS</p>
                            </div>
                            
                  </div>
                          

                   
                </div>
              </div>
               



            </div>


      </div>
    </div>
 </div>










   </div>
















    <script>
      // Get the modal
    var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks on the button, open the modal 
    btn.onclick = function() {
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

    </script>









    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('jquery-easing/jquery.easing.min.js')); ?>"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo e(asset('chart/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('datatables/dataTables.bootstrap4.js')); ?>"></script>



    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('js/sb-admin.min.js')); ?>"></script>


    <!-- Custom scripts for this page-->
    <script src="<?php echo e(asset('js/sb-admin-datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/sb-admin-charts.min.js')); ?>"></script>
  </div>
</body>

</html>